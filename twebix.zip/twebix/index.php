<?php
require"config.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Index CRUD</title>
		<!-- Bootstrap 3.3.7 -->
		<link rel="stylesheet" href="dist/bootstrap/css/bootstrap.min.css">
		<!-- Font Awesome -->
		<link rel="stylesheet" href="dist/font-awesome/css/font-awesome.min.css">
		<!-- DataTables -->
		<link rel="stylesheet" href="dist/datatables.net-bs/css/dataTables.bootstrap.min.css">
		<link rel="stylesheet" href="dist/codebase/webix.css?v=7.3.0" type="text/css" charset="utf-8">
		<script src="dist/codebase/webix.js?v=7.3.0" type="text/javascript" charset="utf-8"></script>

		<link rel="stylesheet" type="text/css" href="dist/common/samples.css?v=7.3.0">
		<script src="dist/common/testdata.js?v=7.3.0" type="text/javascript" charset="utf-8"></script>
	</head>
	<body>
		<div id="dataView"></div>
		<table id="DataView">
		  <tr>
			<th width="40"></th>
			<th> Kode Produk</th>
			<th> Nama Produk</th>
			<th> Kategori Produk</th>
			<th> Stok</th>
			<th></th>
		  </tr>
		  <tr>
			<td>1</td>
			<td>#0rf943jrf0394j</td>
			<td>Tes</td>
			<td>benda</td>
			<td>9</td>
			<td>
				<a class="btn btn-primary" ><i class="fa fa-edit" ></i></a>
				<a class="btn btn-danger" ><i class="fa fa-trash" ></i></a>
			</td>
		  </tr>
		</table>
		<hr>

		<script type="text/javascript" charset="utf-8">
		webix.ready(function(){
			grid = webix.ui({
				container:"dataView",
				view:"datatable",
				columns:[
					{ id:"id",	header:"", css:"rank",  adjust:"data" },
					{ id:"nama_kategori",	header:"Kode Produk", adjust:"data" },
					{ id:"created",	header:"Nama Produk", adjust:"data"},
					{ id:"updated",	header:"Kategori Produk", adjust:"data"},
					{ id:"title",	header:"Stok", adjust:"data"},
					{ id:"votes",	header:"Action", adjust:"data"}
				],
				autoheight:true,
				autowidth:true,
				
				url:"data.php"
			});	
			
			grid = webix.ui({
			  view:"datatable",
			  select:"cell",
			  autoheight:true,
			  autowidth:true
			});
			grid.parse("DataView", "htmltable");
		});
		</script>
	</body>
	
	<!-- jQuery 3 -->
	<script src="dist/jquery/jquery.min.js"></script>
	<!-- Bootstrap 3.3.7 -->
	<script src="dist/bootstrap/js/bootstrap.min.js"></script>
	<!-- Select2 -->
	<script src="dist/select2/js/select2.full.min.js"></script>
	<!-- DataTables -->
	<script src="dist/datatables.net/js/jquery.dataTables.min.js"></script>
	<script src="dist/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
</html>