<?php

// konfigurasi koneksi
$host       =  "localhost";
$dbuser     =  "postgres";
$dbpass     =  "123";
$port       =  "50960";
 $dbname    =  "twebix";

// script koneksi php postgree
$db = new PDO("pgsql:dbname=$dbname;host=$host", $dbuser, $dbpass); 

/*
query insert
*/

//$insert = $db->query("INSERT INTO twebix_kategori_produk (nama_kategori, created, updated) VALUES ('Bahan Bangunan', 'date(Y-m-d H:i:s)', 'date(Y-m-d H:i:s)')");

/*if($insert){
	echo 'berhasil';
}
else {
	echo "gagal";
}*/

/*
query input
*/

/*$view = $db->query("SELECT * FROM twebix_kategori_produk");

while($row = $view->fetch(PDO::FETCH_ASSOC)){
	echo json_encode($row);
}*/

/*
query edit


$created = date('Y-m-d H:i:s');
$updated = date('Y-m-d H:i:s');

$edit = $db->query("UPDATE twebix_kategori_produk SET nama_kategori='Bangunan', created='$created', updated='$updated' WHERE id = '1' ");

if($edit){
	echo 'berhasil';
}
else {
	echo "gagal";
}
*/
?>