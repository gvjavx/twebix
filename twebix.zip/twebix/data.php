<?php
require"config.php";

$view = $db->query("SELECT * FROM twebix_kategori_produk");

while($row = $view->fetch(PDO::FETCH_ASSOC)){
	echo json_encode($row);
}
?>